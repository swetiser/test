#define PAGESIZE 4096
typedef int bool;
#define false 0
#define true 1

#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

FILE *fp;
int leafOrder;
int internalOrder;
int fd;

/*
 * DB를 열고 닫는 메소드
 * close시에는 별도의 인자를 줄 필요가 없다
 */
int open_db(char *_pathname);
int close_db();

// getter
/* 
	getNumberOfKeys
	[page offset 12-15에 있는 키 개수를 가져온다.]
	isLeaf
	[page offset 8-11에 있는 isleaf를 가져온다.]
	getInternalKey
	[internal page offset 128번 부터 16Bytes 간격으로 있는 키를
	가져온다.]
	getInternalOffset
	[internal page offset 120-127에 0번, 128 + 8 번부터
	시작하는 offset을 가져온다.]
	getLeafKey
	[leaf page offset 128번 부터 128Bytes 간격으로 있는 키를
	가져온다.]
	getLeafValue
	[leaf page offset 128 + 8 번부터 시작하는 value 값을
	가져온다. 이 함수는 동적 할당을 하여 그 결과를 리턴하는데, 자신이
	할당 받은 메모리를 돌려 주지 않는다. 따라서 이를 사용 하는
	함수에서 free를 해주어야 한다.]
	getParent
	[page offset 0-7에 있는 parent offset을 가져온다.]
	getNextFreePage
	[free page offset 0-7에 있는 다음 free page의 offset을 가져온다]
	getRightSibling
	[leaf page offset 120 부터 8Bytes에 있는 다음 leaf node의
	offset을 가져온다.]
	getHeaderStatus
	[_stat 값을 입력해 원하는 값을 읽어온다.
	_stat = 1 : free page offset
	_stat = 2 : root page offset
	_stat = 3 : number of pages]
*/
int getNumberOfKeys(int64_t _pageOffset);
int isLeaf(int64_t _pageOffset);
int64_t getInternalKey(int64_t _pageOffset, int _keyNum);
int64_t getInternalOffset(int64_t _pageOffset, int _offsetNum);
int64_t getLeafKey(int64_t _pageOffset, int _keyNum);
char *getLeafValue(int64_t _pageOffset, int _valueNum);
int64_t getParent(int64_t _pageOffset);
int64_t getNextFreePage(int64_t _pageOffset);
int64_t getRightSibling(int64_t _pageOffset);
int64_t getHeaderStatus(int _stat);


// setter
/*
	setInternalKey
	[internal page offset 128번 부터 16Bytes 간격으로 있는 키를
	설정한다.]
	setInternalOffset
	[internal page offset 120-127에 0번, 128 + 8 번부터
	시작하는 offset을 설정한다.]
	setLeafKey
	[leaf page offset 128번 부터 128Bytes 간격으로 있는 키를
	설정한다.]
	setLeafValue
	[leaf page offset 128 + 8 번부터 시작하는 value 값을
	설정한다.]
	setParent
	[page offset 0-7에 있는 parent offset을 설정한다.
	페이지 포맷 특성 상 free page의 다음 offset을 
	설정하는 데도 사용할 수 있다.]
	setNumberOfKeys
	[각 페이지의 offset 12에서 시작하는 키 개수를 설정한다.]
	setRightSibling
	[leaf page의 offset 120 부터 8Bytes에는
	다음 leaf page의 offset이 들어간다. 이를 설정한다.]
	setIsLeaf
	[각 페이지의 is leaf 값을 설정한다.]
	setHeaderStatus
	[_stat과 함께 _info 변수에 원하는 값을 입력해 값을 변경한다.
	_stat의 내용은 get과 동일하다. 단, stat 3번의 경우에는 
	값을 키우거나 줄이는 연산이 자주 사용 되므로
	이를 지원하기 위해 _flag변수를 두어 0이면 set, -1이면 감소,
	1이면 증가 시킨다.]
	upperNumkey
	[각 페이지의 offset 12에서 시작하는 키 개수를 하나 증가 시킨다.]
	lowerNumkey
	[각 페이지의 offset 12에서 시작하는 키 개수를 하나 감소 시킨다.]
	init_page
	[인자로 넘겨받은 페이지를 free Page화 하고 
	마지막 free Page 다음에 붙여준다.]
*/
void setInternalKey(int64_t _pageOffset, int64_t _key, int _keyNum);
void setInternalOffset(int64_t _pageOffset, int64_t _offset, int _offsetNum);
void setLeafKey(int64_t _pageOffset, int64_t _key, int _keyNum);
void setLeafValue(int64_t _pageOffset, char *value, int _ValueNum);
void setNumberOfKeys(int64_t _pageOffset, int _num);
void setParent(int64_t _pageOffset, int64_t _parent);
void setRightSibling(int64_t _pageOffset, int64_t _sibling);
void setIsLeaf(int64_t _pageOffset, int _isLeaf);
void setHeaderStatus(int _stat, int _flag, int64_t _info);
void upperNumKey(int64_t _pageOffset);
void lowerNumKey(int64_t _pageOffset);
void init_page(int64_t _pageOffset);
void initLeaf(int64_t _pageOffset);
void initInternal(int64_t _pageOffset);

// free page management 함수
int64_t freePageToUse();

// insert
int start_new_tree(int64_t _key, char *_value);
int64_t insert_into_leaf(int64_t _leaf, int64_t _key, char *_value);
int64_t insert_into_leaf_after_splitting(int64_t _leaf, 
	int64_t _key, char *_value);
int64_t insert_into_parent(int64_t _left, int64_t _key, int64_t _right);
int64_t insert_into_new_root(int64_t _left, int64_t _key, int64_t _right);
int get_left_index(int64_t _parent, int64_t _left);
void insert_into_node(int64_t _n, int _left_index,
	int64_t _key, int64_t _right);
int64_t insert_into_node_after_splitting(int64_t _oldPage, int _left_index,
	int64_t _key, int64_t right);
int cut(int length);
int insert(int64_t _key, char *_value);

// find
int64_t find_leaf(int64_t _key);
char *find(int64_t _key);
int64_t binarySearch(int64_t _pageOffset, int64_t _key);

// delete
int delete(int64_t _key);
int64_t delete_entry(int64_t _leafKey, int64_t _key);
int64_t adjust_root(int64_t _root);
int64_t redistribute_pages(int64_t _leafKey, int64_t neighbor,
	int neighbor_index, int k_prime_index, int k_prime);
int64_t coalesce_pages(int64_t _leafKey, int64_t _neighbor,
	int neighbor_index, int k_prime);
int get_neighbor_index(int64_t _leafKey);
int64_t remove_entry_from_page(int64_t _leafKey, int64_t _key);

