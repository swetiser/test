#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "bpt.h"

/*
	DataBase file pointer
*/
extern FILE *fp;
extern int leafOrder;
extern int internalOrder;
extern int fd;
char *filename;

int getNumberOfKeys(int64_t _pageOffset){
	int numKey;

	fseek(fp, _pageOffset + 12, SEEK_SET);
	fread(&numKey, sizeof(int), 1, fp);

	return numKey;
}

int isLeaf(int64_t _pageOffset){
	int leaf;

	fseek(fp, _pageOffset + 8, SEEK_SET);
	fread(&leaf, sizeof(int), 1, fp);

	return leaf;
}

int64_t getInternalKey(int64_t _pageOffset, int _keyNum){
	int64_t key;

	fseek(fp, _pageOffset + 128 + _keyNum * 16, SEEK_SET);
	fread(&key, sizeof(int64_t), 1, fp);

	return key;
}
int64_t getInternalOffset(int64_t _pageOffset, int _offsetNum){
	int64_t offset;
	
	fseek(fp, _pageOffset + 120 + _offsetNum * 16, SEEK_SET);
	fread(&offset, sizeof(int64_t), 1, fp);
	
	return offset;
}

int64_t getLeafKey(int64_t _pageOffset, int _keyNum){
	int64_t key;

	fseek(fp, _pageOffset + 128 + 128 * _keyNum, SEEK_SET);
	fread(&key, sizeof(int64_t), 1, fp);

	return key;
}
char * getLeafValue(int64_t _pageOffset, int _valueNum){
	char *tmp;
  tmp = malloc(sizeof(char) * 120);
	fseek(fp, _pageOffset + 128 + 8 + 128*_valueNum, SEEK_SET);
	fread(tmp, 120, 1, fp);
	int len = strlen(tmp) + 1;
	char *value;
	value = malloc(sizeof(char) * len);
	strncpy(value, tmp, len);
  free(tmp);
	return value;
}
int64_t getParent(int64_t _pageOffset){
	int64_t parentOffset;

	fseek(fp, _pageOffset, SEEK_SET);
	fread(&parentOffset, sizeof(int64_t), 1, fp);
  fflush(fp);
  fdatasync(fd);

	return parentOffset;
}

int64_t getNextFreePage(int64_t _pageOffset){
	int64_t nextFreePageOffset;

	fseek(fp, _pageOffset, SEEK_SET);
	fread(&nextFreePageOffset, sizeof(int64_t), 1, fp);

	return nextFreePageOffset;
}
int64_t getRightSibling(int64_t _pageOffset){
	int64_t rightSibling;

	fseek(fp, _pageOffset + 120, SEEK_SET);
	fread(&rightSibling, sizeof(int64_t), 1, fp);

	return rightSibling;
}
int64_t getHeaderStatus(int _stat){
	int64_t headerInfo = 0;
	switch(_stat){
		case 1:
			fseek(fp, 0, SEEK_SET);
			fread(&headerInfo, sizeof(int64_t), 1, fp);
			break;
		case 2:
			fseek(fp, 8, SEEK_SET);
			fread(&headerInfo, sizeof(int64_t), 1, fp);
			break;
		case 3:
			fseek(fp, 16, SEEK_SET);
			fread(&headerInfo, sizeof(int64_t), 1, fp);
		default: break;
	}
	return headerInfo;
}

void setInternalKey(int64_t _pageOffset, int64_t _key, int _keyNum){
	fseek(fp, _pageOffset + 128 + _keyNum * 16, SEEK_SET);
	fwrite(&_key, sizeof(int64_t), 1, fp);
}
void setInternalOffset(int64_t _pageOffset, int64_t _offset, int _offsetNum){
	fseek(fp, _pageOffset + 120 + _offsetNum * 16, SEEK_SET);
	fwrite(&_offset, sizeof(int64_t), 1, fp);
}
void setLeafKey(int64_t _pageOffset, int64_t _key, int _keyNum){
	fseek(fp, _pageOffset + 128 + _keyNum * 128, SEEK_SET);
	fwrite(&_key, sizeof(int64_t), 1, fp);
}
void setLeafValue(int64_t _pageOffset, char *_value, int _valueNum){
  char *tmp;
  
	fseek(fp, _pageOffset + 128 + 8 + _valueNum * 128, SEEK_SET);
  tmp = calloc(15, sizeof(int64_t));
  if(tmp == NULL){
    perror("Memory allocation");
    exit(1);
  }
	if(_value != NULL)
    strncpy(tmp, _value, strlen(_value));
	
  fwrite(tmp, 120, 1, fp);
  free(tmp);
}
void setNumberOfKeys(int64_t _pageOffset, int _num){
	fseek(fp, _pageOffset + 12, SEEK_SET);
	fwrite(&_num, sizeof(int), 1, fp);
}
void setParent(int64_t _pageOffset, int64_t _parent){
	fseek(fp, _pageOffset, SEEK_SET);
	fwrite(&_parent, sizeof(int64_t), 1, fp);
}
void setRightSibling(int64_t _pageOffset, int64_t _sibling){
	fseek(fp, _pageOffset + 120, SEEK_SET);
	fwrite(&_sibling, sizeof(int64_t), 1, fp);
}
void setIsLeaf(int64_t _pageOffset, int _isLeaf){
	fseek(fp, _pageOffset + 8, SEEK_SET);
	fwrite(&_isLeaf, sizeof(int), 1, fp);
}
void setHeaderStatus(int _stat, int _flag, int64_t _info){
	switch(_stat){
		case 1:
			fseek(fp, 0, SEEK_SET);
			fwrite(&_info, sizeof(int64_t), 1, fp);
			break;
		case 2:
			fseek(fp, 8, SEEK_SET);
			fwrite(&_info, sizeof(int64_t), 1, fp);
			break;
		case 3:
		switch(_flag){
			int64_t a;
			case -1:
				a = getHeaderStatus(3) - _info;
				fseek(fp, 16, SEEK_SET);
				fwrite(&a, sizeof(int64_t), 1, fp);
				break;
			case 0:
				fseek(fp, 16, SEEK_SET);
				fwrite(&_info, sizeof(int64_t), 1, fp);
				break;
			case 1:
				a = getHeaderStatus(3) + _info;
				fseek(fp, 16, SEEK_SET);
				fwrite(&a, sizeof(int64_t), 1, fp);
				break;
			default: break;
		}
		default: break;
	}
}
void upperNumKey(int64_t _pageOffset){
	int numKey;
	fseek(fp, _pageOffset + 12, SEEK_SET);
	fread(&numKey, sizeof(int), 1, fp);
	numKey++;
	fseek(fp, _pageOffset + 12, SEEK_SET);
	fwrite(&numKey, sizeof(int), 1, fp);
}
void lowerNumKey(int64_t _pageOffset){
	int numKey;
	fseek(fp, _pageOffset + 12, SEEK_SET);
	fread(&numKey, sizeof(int), 1, fp);
	numKey--;
	fseek(fp, _pageOffset + 12, SEEK_SET);
	fwrite(&numKey, sizeof(int), 1, fp);
}
void delete_page(int64_t _pageOffset){
	int i;
  char *tmp;
  tmp = calloc(16, sizeof(int64_t));
  if(tmp == NULL){
    perror("Memory allocation");
    exit(1);
  }
  for(i = 0; i < 32; i++){
    fseek(fp, _pageOffset + i*128, SEEK_SET);
    fwrite(tmp, 128, 1, fp);
  }

  int64_t bfpOffset = getHeaderStatus(1);
  int64_t nfpOffset;
  while(1){
    nfpOffset = getParent(bfpOffset);
    if(nfpOffset == 0 || nfpOffset == bfpOffset){
      setParent(bfpOffset, _pageOffset);
      break;
    }
    bfpOffset = getParent(bfpOffset);
  }
  free(tmp);
}
void initLeaf(int64_t _pageOffset){
	int i, numKey;
  char *tmp;
  
  tmp = calloc(16, sizeof(int64_t));
	if(tmp == NULL){
    perror("Memory allocation");
    exit(1);
  }
  numKey = getNumberOfKeys(_pageOffset);
	for(i = 0; i < numKey; i++){
		fseek(fp, _pageOffset + 128 * (i + 1), SEEK_SET);
		fwrite(tmp, 128, 1, fp);
	}
	setNumberOfKeys(_pageOffset, 0);
  free(tmp);
}
void initInternal(int64_t _pageOffset){
	int i, numKey;
  
	numKey = getNumberOfKeys(_pageOffset);

	for(i = 0; i < numKey; i++){
		setInternalKey(_pageOffset, 0, i);
		setInternalOffset(_pageOffset, 0, i);
	}
	setInternalOffset(_pageOffset, 0, i);
	setNumberOfKeys(_pageOffset, 0);
}
int open_db(char *_pathname){
	if((fp = fopen(_pathname, "r+")) == NULL){
		if((fp = fopen(_pathname, "w+")) == NULL){
			perror("Can't open file\n");
			return -1;
		}
		/* 
			header page initialize
			파일이 존재하지 않으므로 파일을 생성하고
			Header Page를 초기화 한다.
			Free Page Offset(8bytes)은 PAGESIZE*2,
			Root Page Offset(8bytes)은 PAGESIZE,
			Number of pages(8bytes)는 8로 초기화 한다.
		*/
		setHeaderStatus(1, 0, PAGESIZE * 2);
		setHeaderStatus(2, 0, PAGESIZE);
		setHeaderStatus(3, 0, 8);
		
		/*
		 	root page initialize
		 	header 다음 page를 root로 지정한다.
		 	parent는 header = 0,
		    최초에는 leaf 이므로 isLeaf = 1,
		 	number of keys = 0 이다.
		 	leaf는 나중에 설정한다.
		 	따라서 write하지 않는다.
		
			free page initialize
			첫 free page는 header = 0, root = 1
			따라서 2번으로 한다.
			임의로 6개를 먼저 지정해 놓는다.
		*/
		int i;
		for(i = 2; i < 7; i++){
			setParent(PAGESIZE * i, PAGESIZE * (i + 1));
		}
	}
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  filename = (char *) malloc(strlen(_pathname) + 1);
  strncpy(filename, _pathname, strlen(_pathname) + 1);
  leafOrder = 32;
  internalOrder = 248;
  fd = fileno(fp);
	return 0;
}
int close_db(){
  free(filename);
  fclose(fp);
  return 0;
}
int start_new_tree(int64_t _key, char *_value){
	int64_t root = getHeaderStatus(2);
	// revise Root page and add (key, value) pair
	setIsLeaf(root, 1);
	setLeafKey(root, _key, 0);
	setLeafValue(root, _value, 0);
  setParent(root, 0);
  upperNumKey(root);

	return 0;
}

/*
	H R F F F F ? 일 때 4번째 free page는 ?의 offset을 저장하지만
	?는 비할당 상태이고 만약 freePage를 얻어와야 하는데 header의
	free page offset이 ?의 오프셋이 되었다면 새로 free page를 할당
	해야 한다.
	아래의 코드는 위의 역할을 하는 free page getter 이다.
*/
int64_t freePageToUse(){
	int64_t freePageOffset = getHeaderStatus(1);
	int64_t nextFreePageOffset = getParent(freePageOffset); 
	// revise header's free page offset
	// 남은 free page가 없으면 또 5개를 새로 생성한다.
  int isEmpty = getNumberOfKeys(freePageOffset);
	if(isEmpty){
		int64_t numberOfPages = getHeaderStatus(3);

		int i = numberOfPages;
    setHeaderStatus(1, 0, PAGESIZE*i);
		for(; i < numberOfPages + 5; i++){
			setParent(PAGESIZE * i, PAGESIZE * (i + 1));	
		}

		// revise header page
		/* 
			페이지 수가 늘어나는 곳은 이 함수 뿐이므로
			여기에서 페이지 수를 늘리면 된다
		*/
		setHeaderStatus(3, 1, 5);
    return PAGESIZE * numberOfPages;
	}
	setNumberOfKeys(freePageOffset, 0);
	setHeaderStatus(1, 0, nextFreePageOffset);
	return freePageOffset;
}
int64_t insert_into_leaf(int64_t _leaf, int64_t _key,
	char *_value){
	int i, insertion_point = 0;
	int numKey = getNumberOfKeys(_leaf);

	while(insertion_point < numKey && 
		getLeafKey(_leaf, insertion_point) < _key)
		insertion_point++;

	for(i = getNumberOfKeys(_leaf); i > insertion_point; i--){
		setLeafKey(_leaf, getLeafKey(_leaf, i - 1), i);
		setLeafValue(_leaf, getLeafValue(_leaf, i - 1), i);
	}
	setLeafKey(_leaf, _key, insertion_point);
	setLeafValue(_leaf, _value, insertion_point);
	upperNumKey(_leaf);
	return _leaf;
}
// 이 함수는 leaf page에 대해서만 작동
int64_t insert_into_leaf_after_splitting(int64_t _leaf, 
	int64_t _key, char *_value){
	int64_t *tempKeys;
	char **tempValues;
	int insertion_index, split, new_key, i, j, numKeyLeaf;
	int64_t newPage;

	// 새로운 free page를 할당.
	newPage = freePageToUse();
	setIsLeaf(newPage, 1);
	tempKeys = malloc(leafOrder * sizeof(int64_t));
	if(tempKeys == NULL){
		perror("Temporary keys array.");
		exit(1);
	}

	tempValues = malloc(leafOrder * sizeof(char *));
	if(tempValues == NULL){
		perror("Temporary values array.");
		exit(1);
	}

	insertion_index = 0;
	while(insertion_index < leafOrder - 1 && 
		getLeafKey(_leaf, insertion_index) < _key)
		insertion_index++;

	numKeyLeaf = getNumberOfKeys(_leaf);
	for(i = 0, j = 0; i < numKeyLeaf; i++, j++){
		if(j == insertion_index) j++;
		tempKeys[j] = getLeafKey(_leaf, i);
		tempValues[j] = getLeafValue(_leaf, i);
	}
	tempKeys[insertion_index] = _key;
	tempValues[insertion_index] = _value;
	initLeaf(_leaf);
	split = cut(leafOrder - 1);
	
	for(i = 0; i < split; i++){
		setLeafValue(_leaf, tempValues[i], i);
		setLeafKey(_leaf, tempKeys[i], i);
		upperNumKey(_leaf);
	}
	for(i = split, j = 0; i < leafOrder; i++, j++){
		setLeafValue(newPage, tempValues[i], j);
		setLeafKey(newPage, tempKeys[i], j);
		upperNumKey(newPage);
	}
	free(tempKeys);
	free(tempValues);
	int64_t sibling = getRightSibling(_leaf);
	setRightSibling(_leaf, newPage);
	setRightSibling(newPage, sibling);

	setParent(newPage, getParent(_leaf));
	new_key = getLeafKey(newPage, 0);
	return insert_into_parent(_leaf, new_key, newPage);
}
int64_t insert_into_parent(int64_t _left, int64_t _key, int64_t _right){
	int left_index;
	int64_t parent;


	/* 
		새로운 root가 생기는 경우
		즉, 인자인 _left가 본래 root 였던 경우이다.
	*/
  parent = getParent(_left);

	if(parent == 0)
		return insert_into_new_root(_left, _key, _right);

	/* 일반 페이지에 추가되는 경우 */

	/* left node의 parent에서의 위치를 구한다. */
	left_index = get_left_index(parent, _left);

	/* 
		key를 페이지에 삽입 가능한 경우
		fill factor > numberOfKey(node);
	 */
	if(getNumberOfKeys(parent) < internalOrder - 1){
		insert_into_node(parent, left_index, _key, _right);
    
		return 0;
	}

	/* 해당 페이지의 fill factor가 가득 찬 경우 */
	return insert_into_node_after_splitting(parent, left_index, _key, _right);
}
int64_t insert_into_new_root(int64_t _left, int64_t _key, int64_t _right){
	int64_t root = freePageToUse();
	setIsLeaf(root, 0);
	setInternalKey(root, _key, 0);
	setInternalOffset(root, _left, 0);
	setInternalOffset(root, _right, 1);
	upperNumKey(root);
	setParent(root, 0);
	setParent(_left, root);
	setParent(_right, root);
	setHeaderStatus(2, 0, root);
	return root;
}
int get_left_index(int64_t _parent, int64_t _left){
	int left_index = 0;

	while(left_index <= getNumberOfKeys(_parent) &&
		getInternalOffset(_parent, left_index) != _left)
		left_index++;
	return left_index;
}
void insert_into_node(int64_t _n, int _left_index,
	int64_t _key, int64_t _right){
	int i;

	for(i = getNumberOfKeys(_n); i > _left_index; i--){
		setInternalOffset(_n, getInternalOffset(_n, i), i + 1);
		setInternalKey(_n, getInternalKey(_n, i - 1), i);
	}
	setInternalOffset(_n, _right, _left_index + 1);
	setInternalKey(_n, _key, _left_index);
	upperNumKey(_n);
}
int64_t insert_into_node_after_splitting(int64_t _oldPage, int _left_index,
	int64_t _key, int64_t _right){
	int i, j, split, k_prime;
	int64_t newPage, child;
	int64_t *tempKeys;
	int64_t *tempOffsets;

	tempKeys = malloc(internalOrder * sizeof(int64_t));
	if(tempKeys == NULL){
		perror("Temporary Keys array for splitting pages");
		exit(1);
	}
	tempOffsets = malloc((internalOrder + 1) * sizeof(int64_t));
	if(tempOffsets == NULL){
		perror("Temporary values array for splitting pages");
		exit(1);
	}

	int numKey = getNumberOfKeys(_oldPage);
	for(i = 0, j = 0; i < numKey + 1; i++, j++){
		if (j == _left_index + 1) j++;
		tempOffsets[j] = getInternalOffset(_oldPage, i);
	}

	for(i = 0, j = 0; i < numKey; i++, j++){
		if (j == _left_index) j++;
		tempKeys[j] = getInternalKey(_oldPage, i);
	}

	tempOffsets[_left_index + 1] = _right;
	tempKeys[_left_index] = _key;

	split = cut(internalOrder);

	newPage = freePageToUse();
	initInternal(_oldPage);

	for(i = 0; i < split - 1; i++){
		setInternalOffset(_oldPage, tempOffsets[i], i);
		setInternalKey(_oldPage, tempKeys[i], i);
		upperNumKey(_oldPage);
	}
	setInternalOffset(_oldPage, tempOffsets[i], i);
	k_prime = tempKeys[split - 1];
	for(++i, j = 0; i < internalOrder; i++, j++){
		setInternalOffset(newPage, tempOffsets[i], j);
		setInternalKey(newPage, tempKeys[i], j);
		upperNumKey(newPage);
	}
	setInternalOffset(newPage, tempOffsets[i], j);
	free(tempOffsets);
	free(tempKeys);
	setParent(newPage, getParent(_oldPage));
	numKey = getNumberOfKeys(newPage);

	for(i = 0; i <= numKey; i++){
    child = getInternalOffset(newPage, i);
 	  setParent(child, newPage);
 	}

	return insert_into_parent(_oldPage, k_prime, newPage);
}
int cut(int length){
	if(length % 2 == 0)
		return length / 2;
	else
		return length/2 + 1;
}
int insert(int64_t _key, char *_value){
	int64_t leaf;
	/*
		이미 해당 key가 존재하면 insert하지 않고,
		-2를 return 한다.
	*/
	if(find(_key) != NULL){
		return -2;
	}

	/*
		Root가 하나도 키를 가지고 있지 않은 경우에
		start_new_tree(int, char*)를 호출하여
		새로운 트리를 만든다.
	*/
	if(getNumberOfKeys(getHeaderStatus(2)) == 0){
		start_new_tree(_key, _value);
		fflush(fp);
		fdatasync(fd);
		return 0;
	}
	
	/*
		이미 트리가 존재하는 경우에 대해서 기술한다.
	*/

	leaf = find_leaf(_key);
	/*
		leaf page에 자리가 남아 있을 경우
	*/

	if (getNumberOfKeys(leaf) < leafOrder - 1){
		insert_into_leaf(leaf, _key, _value);
		fflush(fp);
		fdatasync(fd);
		return 0;
	}
	/*
		leaf page가 반드시 split 되어야 하는 경우
	*/
	insert_into_leaf_after_splitting(leaf, _key, _value);
	fflush(fp);
	fdatasync(fd);
	return 0;
}
int64_t find_leaf(int64_t _key){
	int i = 0;
	int64_t c = getHeaderStatus(2);
	
	if(getNumberOfKeys(c) == 0)
		return c;
	while(!isLeaf(c)){
    //i = binarySearch(c, _key);
		i = 0;
		int numKey = getNumberOfKeys(c);
		while(i < numKey){
			if (_key >= getInternalKey(c, i)) i++;
			else break;
		}
		c = getInternalOffset(c, i);
	}
	return c;
}

char *find(int64_t _key){
	int i = 0;
	int64_t c = find_leaf(_key);
	if(getNumberOfKeys(c) == 0) return NULL;

	/*int numKey = getNumberOfKeys(c);
	for(i = 0; i < numKey; i++)
		if(getLeafKey(c, i) == _key) break;*/
  i = binarySearch(c, _key);
	//if(i == numKey)
  if(i == -1)
		return NULL;
	else
		return getLeafValue(c, i);
}
int64_t binarySearch(int64_t _pageOffset, int64_t _key){
  int low = 0, high = getNumberOfKeys(_pageOffset) - 1, mid;

  if(!isLeaf(_pageOffset)){
    while(low <= high){
      mid = (low + high) / 2;
      if(getInternalKey(_pageOffset, mid) > _key) high = mid - 1;
      else if(getInternalKey(_pageOffset, mid) < _key) low = mid + 1;
      else return mid;
    }
    if(getInternalKey(_pageOffset, mid) < _key) return mid + 1;
  }
  else{
    while(low <= high){
      mid = (low + high) / 2;
      if(getLeafKey(_pageOffset, mid) > _key) high = mid - 1;
      else if(getLeafKey(_pageOffset, mid) < _key) low = mid + 1;
      else return mid;
    }
  }
  return -1;
}
// deletion
int64_t delete_entry(int64_t _leafKey, int64_t _key){
	int min_keys;
	int64_t neighbor;
	int neighbor_index;
	int k_prime_index;
	int64_t k_prime;
	int capacity;

	// leaf page에서 key와 value를 제거한다.
	_leafKey = remove_entry_from_page(_leafKey, _key);
	/*
		root 에서 deletion이 발생한 경우
	*/
	if(_leafKey == getHeaderStatus(2)){
		return adjust_root(getHeaderStatus(2));
  }
	/*
		최소 가지고 있어야 하는 page의 개수를 지정한다.
	*/
	min_keys = isLeaf(_leafKey) ? cut(leafOrder - 1) : cut(internalOrder) - 1;

	/*
		internal page가 최소 가지고 있어야 할 page 이상을
		지운 뒤에도 가지고 있는 경우
	*/
	if(getNumberOfKeys(_leafKey) >= min_keys){
		return;
  }

	/*
		internal page가 최소 가지고 있어야 할 page 보다
		적게 가지게 되는 경우		
		재분배 혹은 병합이 필요할 것이다.
	*/

	/*
		병합하기에 적절한 neighbor page를 찾는다.
		또한 
	*/

	neighbor_index = get_neighbor_index(_leafKey);
	k_prime_index = neighbor_index == -1 ? 0 : neighbor_index;
	k_prime = getInternalKey(getParent(_leafKey), k_prime_index);
	neighbor = neighbor_index == -1 ? 
		getInternalOffset(getParent(_leafKey), 1) :
			getInternalOffset(getParent(_leafKey), neighbor_index);

	capacity = isLeaf(_leafKey) ? leafOrder : internalOrder - 1;
	/* 병합 */

	if(getNumberOfKeys(neighbor) + getNumberOfKeys(_leafKey) < capacity)
		return coalesce_pages(_leafKey, neighbor, neighbor_index, k_prime);

	/* 재배치 */

	else
		return redistribute_pages(_leafKey, neighbor, neighbor_index,
			k_prime_index, k_prime);
}
int64_t adjust_root(int64_t _root){
	int64_t newRoot;
	/*
		root가 empty가 아닐 떄
		더 이상 할 일이 없으므로 리턴한다. 
	*/
	if(getNumberOfKeys(_root) > 0)
		return _root;

	/*
		empty root
	*/

	// 만약 child를 가지고 있다면 그것을 new root로 한다.
	if(!isLeaf(_root)){
		newRoot = getInternalOffset(_root, 0);
		setHeaderStatus(2, 0, newRoot);
		setParent(newRoot, 0);
	}

	// 만약 root가 leaf 라면 b+ tree는 빈 것이다.
	else{ 
		newRoot = 0;
    fclose(fp);
    remove(filename);
    open_db(filename);
  }

	delete_page(_root);

	return newRoot;
}
int64_t redistribute_pages(int64_t _leafKey, int64_t neighbor,
	int neighbor_index, int k_prime_index, int k_prime){

	int i;
	int64_t tmp;
	/*
		_leafKey가 neighbor를 왼쪽에 가지고 있을 경우
	*/

	if(neighbor_index != -1){
		if(!isLeaf(_leafKey)){
			setInternalOffset(_leafKey, 
				getInternalOffset(_leafKey, getNumberOfKeys(_leafKey)),
				getNumberOfKeys(_leafKey) + 1);
		  for(i = getNumberOfKeys(_leafKey); i > 0; i--){
			  setInternalKey(_leafKey, getInternalKey(_leafKey, i - 1), i);
			  setInternalOffset(_leafKey, getInternalOffset(
				  _leafKey, i - 1), i);
		  }
    } else {
      for(i = getNumberOfKeys(_leafKey); i > 0; i--){
        setLeafKey(_leafKey, getLeafKey(_leafKey, i - 1), i);
        setLeafValue(_leafKey, getLeafValue(_leafKey, i - 1), i);
      }
    }
		if(!isLeaf(_leafKey)){
			setInternalOffset(_leafKey, getInternalOffset(neighbor,
				getNumberOfKeys(neighbor)), 0);
			tmp = getInternalOffset(_leafKey, 0);
			setParent(tmp, _leafKey);
			setInternalOffset(neighbor, 0, getNumberOfKeys(neighbor));
			setInternalKey(_leafKey, k_prime, 0);
			setInternalKey(getParent(_leafKey), getInternalKey(neighbor,
				getNumberOfKeys(neighbor) - 1), k_prime_index);
		} else {
			setLeafValue(_leafKey, getLeafValue(neighbor,
				getNumberOfKeys(neighbor) - 1), 0);
			setLeafValue(neighbor, NULL, getNumberOfKeys(neighbor) - 1);
			setLeafKey(_leafKey, getLeafKey(neighbor, getNumberOfKeys(
				neighbor) - 1), 0);
			setInternalKey(getParent(_leafKey), getLeafKey(_leafKey, 0),
				k_prime_index);
		}
	}

	else {
		if(isLeaf(_leafKey)){
			setLeafKey(_leafKey, getLeafKey(neighbor, 0), 
				getNumberOfKeys(_leafKey));
			setLeafValue(_leafKey, getLeafValue(neighbor, 0),
				getNumberOfKeys(_leafKey));
			setInternalKey(getParent(_leafKey), getLeafKey(neighbor, 1),
				k_prime_index);
		} else {
			setInternalKey(_leafKey, k_prime, getNumberOfKeys(_leafKey));
			setInternalOffset(_leafKey, getInternalOffset(neighbor, 0),
				getNumberOfKeys(_leafKey) + 1);
			tmp = getInternalOffset(_leafKey, getNumberOfKeys(_leafKey) - 1);
			setParent(tmp, _leafKey);
			setInternalKey(getParent(_leafKey), getInternalKey(
				neighbor, 0), k_prime_index);
		}
		if(!isLeaf(neighbor)){
			for(i = 0; i < getNumberOfKeys(neighbor) - 1; i++){
				setInternalKey(neighbor, getInternalKey(neighbor, i + 1), i);
				setInternalOffset(neighbor,
					getInternalOffset(neighbor, i + 1), i);			
			}
		} else {
			for(i = 0; i < getNumberOfKeys(neighbor) - 1; i++){
				setLeafKey(neighbor, getLeafKey(neighbor, i + 1), i);
				setLeafValue(neighbor,
					getLeafValue(neighbor, i + 1), i);			
			}
		}
		if(!isLeaf(_leafKey))
			setInternalOffset(neighbor, getInternalOffset(
				neighbor, i + 1), i);		
	}

	upperNumKey(_leafKey);
	lowerNumKey(neighbor);

	return getHeaderStatus(2);
}
int64_t coalesce_pages(int64_t _leafKey, int64_t neighbor,
	int neighbor_index, int k_prime){

	int i, j, neighbor_insertion_index, leafKey_end;
	int64_t tmp;

	/*
		_leafKey가 극단적으로 왼쪽에 있고 바로 옆에 neighbor가
		존재하면 둘의 위치를 바꿔준다.
	*/

	if(neighbor_index == -1){
    setInternalOffset(getParent(_leafKey), neighbor, 0);
    setInternalOffset(getParent(_leafKey), _leafKey, 1);
		tmp = _leafKey;
		_leafKey = neighbor;
		neighbor = tmp;
	}

	/*
		_leafKey로 부터 key와 value를 copying 하기 위한
		시작 index를 설정한다.
	*/
	neighbor_insertion_index = getNumberOfKeys(neighbor);

	/*
		leaf가 하나도 없는 page.
	*/

	if(!isLeaf(_leafKey)){

		k_prime = getInternalKey(neighbor, neighbor_insertion_index);
		upperNumKey(neighbor);

		leafKey_end = getNumberOfKeys(_leafKey);

		for(i = neighbor_insertion_index + 1, j = 0; j < leafKey_end;
			i++, j++){
			setInternalKey(neighbor, getInternalKey(_leafKey, j), i);
			setInternalOffset(neighbor, getInternalOffset(_leafKey, j), i);
			upperNumKey(neighbor);
			lowerNumKey(_leafKey);
		}
		/*
			offset의 수는 항상 key보다 하나 많아야 한다.
		*/

		setInternalOffset(neighbor, getInternalOffset(_leafKey, j), i);

		/*
			모든 자식들은 이제 반드시 같은 parent를 가리켜야 한다.
		*/

		for(i = 0; i < getNumberOfKeys(neighbor) + 1; i++){
			tmp = getInternalOffset(neighbor, i);
			setParent(tmp, neighbor);
		}
	}
	/* 
		leaf page의 경우 병합 방법
	*/
	else {
		for(i = neighbor_insertion_index, j = 0; 
				j < getNumberOfKeys(_leafKey); i++, j++){
			setLeafKey(neighbor, getLeafKey(_leafKey, j), i);
			setLeafValue(neighbor, getLeafValue(_leafKey, j), i);
			upperNumKey(neighbor);
		}
    setParent(neighbor, getParent(_leafKey));
	}

	int64_t k = delete_entry(getParent(_leafKey), k_prime);
	delete_page(_leafKey);
	return k;
}
int get_neighbor_index(int64_t _leafKey){
	int i;

	/*
		parent가 _leafKey를 가리키고 있는 바로 앞의
		키의 인덱스를 가져온다.
	*/
	int numKey = getNumberOfKeys(getParent(_leafKey));
	for(i = 0; i < numKey; i++)
		if(getInternalOffset(getParent(_leafKey), i) == _leafKey)
			return i - 1;

  // 만약 _leafKey가 가장 왼쪽의 page라면 -1을 리턴한다.
	return -1;
}
int64_t remove_entry_from_page(int64_t _leafKey, int64_t _key){
	int i, j, numKey;
	// key, value를 제거하고 다른 key, value를 한 칸씩 당겨온다.
	i = 0;
	numKey = getNumberOfKeys(_leafKey);
	if(isLeaf(_leafKey)){
		while(getLeafKey(_leafKey, i) != _key) i++;
		for(++i; i < numKey; i++){
			setLeafKey(_leafKey, getLeafKey(_leafKey, i), i - 1);
			setLeafValue(_leafKey, getLeafValue(_leafKey, i), i - 1);		
		}			
	} else {
		while(getInternalKey(_leafKey, i) != _key) i++;
		j = i;
		for(++i; i < numKey; i++)
			setInternalKey(_leafKey, getInternalKey(_leafKey, i), i - 1);
		for(++j; j < numKey + 1; j++)
			setInternalOffset(_leafKey, getInternalOffset(_leafKey,	j)
				, j - 1);
	}
  fflush(fp);
  fdatasync(fd);
	lowerNumKey(_leafKey);
	// value 값을 모두 비운다.
	if(isLeaf(_leafKey)){
    setLeafKey(_leafKey, 0, getNumberOfKeys(_leafKey));
    char *tmp = getLeafValue(_leafKey, getNumberOfKeys(_leafKey));
    free(tmp);
		setLeafValue(_leafKey, NULL, getNumberOfKeys(_leafKey));
  }
	else{
    setInternalKey(_leafKey, 0, getNumberOfKeys(_leafKey));
	  setInternalOffset(_leafKey, 0, getNumberOfKeys(_leafKey) + 1);
  }
	return _leafKey;
}

/*
	delete에 성공하면 0을 리턴, 실패하면 -1을 리턴한다.
*/
int delete(int64_t _key){
	int64_t leafKey;
	char *leafValue;

	leafValue = find(_key);
	leafKey = find_leaf(_key);
	if(leafValue != NULL && leafKey != 0){
		delete_entry(leafKey, _key);
		fflush(fp);
    fdatasync(fd);
		return 0;
	}
	return -1;
}
